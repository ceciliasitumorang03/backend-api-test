package com.example.backendtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendTestApplication {
    public static void main(String[] args) {
        SpringApplication.run(BackendTestApplication.class, args);
    }
}
